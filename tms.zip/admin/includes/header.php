<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"></script>
  <script>
    WebFont.load({
      google: {
        families: ["Cookie:regular"]
      }
    });
</script>
<div class="header-main">
					<div style="background:#333;" class="logo-w3-agile">
								<h1 style="font-family: Cookie; color:#333;"><a href="dashboard.php">Data Management System<br><small>Welcome to the admin panel, manage your website from here.</small></a></h1>
							</div>
				
						
						<div style="padding:1.5em 1em" class="profile_details w3l">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/User-icon.png" alt=""> </span> 
												<div class="user-name">
													<p style="font-family: Cookie; font-size:25px;color:#333;">Welcome</p>
													<span style="font-family: Cookie; font-size:25px; color:#333;">Administrator</span>
												</div>
												<i class="fa fa-angle-down"></i>
												<i class="fa fa-angle-up"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="change-password.php"><i class="fa fa-user"></i> Profile</a> </li> 
											<li> <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>
							
				     <div class="clearfix"> </div>	
				</div>