<div class="copyrights">
	 <p>© 2020 Shaun Global Tourism. All Rights Reserved |  <a href="#">SGT</a> </p>
</div>	
